package sync

//Implements the synchronization mechanism (tracking sequence numbers,
//detecting gaps, handling periodic full-state updates, and managing ACKs).